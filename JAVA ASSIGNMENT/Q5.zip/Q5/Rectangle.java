class Rectangle extends Shapes {

  public void draw() {
    System.out.println("Drawing a rectangle...");
  }
}
