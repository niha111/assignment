abstract class Shapes 
{
		public abstract void draw();	
}

