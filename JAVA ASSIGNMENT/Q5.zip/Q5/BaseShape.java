
public class BaseShape {
	
	 public static void drawShapes(Shapes[] list) {
		    for (int i = 0; i < list.length; i++) {
		      list[i].draw();
		    }
		  }

	 public static void main(String args[])
	 {
		 Shapes[] shapeList = new Shapes[2];
		 shapeList[0] = new Rectangle();
		 shapeList[1] = new Cube(); 
		 drawShapes(shapeList);
	 }
}
